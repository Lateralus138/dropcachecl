# dropcachecl
Edit the '/proc/sys/vm/drop_caches' file with some options.
