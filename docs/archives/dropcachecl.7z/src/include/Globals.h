#pragma once
#ifndef GLOBALS_H
#define GLOBALS_H
#include <string>
namespace Globals
{
  extern std::string to_lower(std::string anyCaseString);
  extern std::string time_utc();
};
#endif
